# K2 Lanches - Cardápio Digital

Um cardápio web moderno, inovador e responsivo para a **K2 Lanches de Laurentino**. Desenvolvido com HTML5, CSS3 e JavaScript vanilla, sem dependências externas.

## 🎯 Características

- **Design Moderno e Inovador**: Interface limpa com gradientes, animações suaves e efeitos visuais impressionantes
- **Navegação por Abas**: Sistema de abas intuitivo para navegar entre categorias
- **Responsivo**: Funciona perfeitamente em desktop, tablet e mobile
- **Efeitos de Scroll**: Animações suaves e parallax effects
- **Sem Dependências**: Apenas HTML, CSS e JavaScript vanilla
- **Performance**: Carregamento rápido e otimizado
- **SEO Friendly**: Estrutura semântica e meta tags

## 📋 Categorias do Cardápio

1. **Início** - Página inicial com logo e informações da lanchonete
2. **Lanches** - Mais de 30 opções de lanches variados
3. **Porções** - Porções para compartilhar e frutos do mar
4. **Bebidas** - Sucos, refrigerantes, cervejas e chopps
5. **Sobremesa** - Petit Gateau, Sorvete e Açaí

## 🚀 Como Usar

### Instalação Local

1. Clone ou baixe este repositório
2. Abra o arquivo `index.html` em seu navegador
3. Pronto! O cardápio está funcionando

```bash
git clone https://github.com/seu-usuario/k2-lanches-menu.git
cd k2-lanches-menu
# Abra index.html no navegador
```

### Estrutura de Arquivos

```
k2-lanches-menu/
├── index.html                 # Arquivo principal
├── src/
│   ├── styles/
│   │   ├── style.css         # Estilos CSS
│   │   ├── script.js         # JavaScript interativo
│   │   └── (imagens)         # Imagens do cardápio
│   └── assets/
│       └── images/           # Imagens do cardápio
├── README.md                 # Este arquivo
└── .gitignore               # Arquivos a ignorar no Git
```

## 🎨 Personalização

### Alterar Cores

Edite as variáveis CSS no arquivo `src/styles/style.css`:

```css
:root {
    --primary-color: #ff6b35;      /* Cor primária (laranja) */
    --secondary-color: #f7931e;    /* Cor secundária (laranja claro) */
    --accent-color: #ffd700;       /* Cor de destaque (amarelo) */
    --dark-bg: #1a1a1a;           /* Fundo escuro */
    --light-bg: #f5f5f5;          /* Fundo claro */
}
```

### Adicionar Novos Itens

Para adicionar novos itens ao cardápio, adicione um novo `item-card` dentro da seção desejada:

```html
<div class="item-card">
    <div class="item-image" style="background: linear-gradient(135deg, #ff6b35, #f7931e);"></div>
    <div class="item-content">
        <h3>Nome do Item</h3>
        <p class="item-description">Descrição do item</p>
        <p class="item-price">R$ XX,XX</p>
    </div>
</div>
```

### Adicionar Imagens

Coloque as imagens na pasta `src/assets/images/` e referencie-as no HTML:

```html
<img src="src/assets/images/seu-arquivo.png" alt="Descrição">
```

## 📱 Responsividade

O cardápio é totalmente responsivo com breakpoints para:

- **Desktop**: 1200px+
- **Tablet**: 768px - 1199px
- **Mobile**: Até 767px
- **Pequenos Celulares**: Até 480px

## 🔧 Funcionalidades JavaScript

### Navegação por Abas
- Clique nos links da navbar para trocar de seção
- A navegação é atualizada automaticamente ao fazer scroll

### Efeitos de Scroll
- Animações suaves ao entrar em view
- Parallax effect na imagem do hero
- Navbar que desaparece ao fazer scroll para baixo

### Busca (Opcional)
Use a função `searchItems()` no console:
```javascript
searchItems('frango') // Busca por itens contendo "frango"
```

### Contador de Itens
```javascript
countItemsByCategory() // Retorna o número de itens por categoria
```

## 📞 Informações de Contato

- **Endereço**: Rua 1º de Maio, 111 - Centro - Laurentino
- **Telefone/WhatsApp**: (47) 98834-5687
- **Instagram**: @k2lanche
- **Facebook**: @K2lanchesdelaurentino
- **Horário**: Aberto Terça a Domingo
- **Disk Entrega**: Quarta a Domingo

## 🌐 Deploy

### GitHub Pages

1. Faça push do repositório para o GitHub
2. Vá em Settings > Pages
3. Selecione "Deploy from a branch"
4. Escolha a branch `main` e pasta `root`
5. Clique em Save

Seu cardápio estará disponível em: `https://seu-usuario.github.io/k2-lanches-menu/`

### Netlify

1. Conecte seu repositório GitHub ao Netlify
2. Configure a build (deixe em branco para sites estáticos)
3. Deploy automático a cada push

### Vercel

1. Importe o repositório no Vercel
2. Clique em Deploy
3. Seu site estará online em minutos

## 📝 Licença

Este projeto é de uso livre para a K2 Lanches.

## 🤝 Contribuições

Sugestões e melhorias são bem-vindas! Sinta-se à vontade para fazer um fork e enviar pull requests.

## 📧 Suporte

Para dúvidas ou sugestões sobre o cardápio, entre em contato com a K2 Lanches através dos canais de comunicação acima.

---

**Desenvolvido com ❤️ para K2 Lanches**

Última atualização: Janeiro de 2024
